import os

base_path = "."
this_file = os.path.abspath(__file__)  

for root, dirs, files in os.walk(base_path):
    for file in files:
        path = os.path.join(root, file)
        if os.path.abspath(path) == this_file:
            continue  
        try:
            with open(path, 'r', errors="ignore") as f:
                content = f.read()
                if "miniCTF{" in content:
                    print(f"Flag found in: {path}")
                    print(content)
                    exit()
        except Exception as e:
            print(f"Error reading {path}: {e}")
